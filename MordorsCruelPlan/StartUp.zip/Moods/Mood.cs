﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Moods
{
    public class Mood
    {
        public virtual string Name => "Mood";
    }
}
