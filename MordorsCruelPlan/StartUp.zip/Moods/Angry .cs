﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Moods
{
    public class Angry : Mood
    {
        public override string Name => "Angry";
    }
}
